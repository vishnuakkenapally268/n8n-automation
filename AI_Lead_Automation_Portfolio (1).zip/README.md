# AI Lead Qualification & Follow-up Automation

## Portfolio Project
A production-style n8n automation concept that captures website leads, validates incoming data, qualifies leads, assigns priority, prepares a CRM-ready record, and generates a personalized follow-up message.

## Workflow
1. Lead Webhook receives a website form submission.
2. Normalize Lead cleans and standardizes the payload.
3. Valid Email? checks whether the lead contains an email.
4. AI-Ready Qualification evaluates the lead message and assigns:
   - Qualified / Needs Review
   - High / Normal priority
5. Prepare CRM Record creates a structured CRM-ready object.
6. Create Follow-up generates an email subject and response.
7. Webhook Response returns a JSON success response.

## Sample input
{
  "name": "Rahul Kumar",
  "email": "rahul@example.com",
  "company": "Demo Technologies",
  "message": "We need an automation demo and pricing today.",
  "source": "Website"
}

## Sample result
The workflow marks the lead as Qualified with High priority and prepares a follow-up message.

## How to use
1. Open n8n.
2. Import `n8n_ai_lead_automation.json`.
3. Connect your preferred email and CRM credentials if you want to turn the demo into a live automation.
4. Replace the demo qualification Code node with an OpenAI node if AI-based classification is required.
5. Connect the CRM node (HubSpot, Airtable, Google Sheets, etc.) and email provider.
6. Test the webhook with the sample payload.

## Portfolio note
This package intentionally contains no real credentials, API keys, personal data, or customer information. It is designed as a safe portfolio demonstration.
